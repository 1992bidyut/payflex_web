<div class="row widget-row">
    
    <!--------------------------------  TODAY'S Order count  -------------------------------->
    <div class="col-md-3">
        <!-- BEGIN WIDGET THUMB -->
        <div class="widget-thumb widget-bg-color-white text-uppercase margin-bottom-20 bordered">
            <h4 class="widget-thumb-heading">TODAY's Order</h4>
            <div class="widget-thumb-wrap">
                <i class="widget-thumb-icon bg-green icon-envelope"></i>
                <div class="widget-thumb-body">
                    <span class="widget-thumb-subtitle">Count</span>
                    <a href="<?php echo base_url('Dashboard/orderDetailsTable/').'todaySuccessSms';?>">
                    <span class="widget-thumb-body-stat" id="OrderCountBox" >
                        <img src="<?php echo base_url('assets/images/loading-count.gif') ;?>">
                    </span>
                    </a>
                </div>
            </div>
        </div>
        <!-- END WIDGET THUMB -->
    </div>
    <!--------------------------------  TODAY'S Payment Counts  -------------------------------->
    <div class="col-md-3">
        <!-- BEGIN WIDGET THUMB -->
        <div class="widget-thumb widget-bg-color-white text-uppercase margin-bottom-20 bordered">
            <h4 class="widget-thumb-heading">TODAY'S Payment</h4>
            <div class="widget-thumb-wrap">
                <i class="widget-thumb-icon bg-green icon-envelope"></i>
                <div class="widget-thumb-body">
                    <span class="widget-thumb-subtitle">Counts</span>
                    <a href="<?php echo base_url('Dashboard/smsHistory/').'todaySuccessSms';?>">
                    <span class="widget-thumb-body-stat" id="PaymentCountBox" >
                        <img src="<?php echo base_url('assets/images/loading-count.gif');?>">
                    </span>
                    </a>
                </div>
            </div>
        </div>
        <!-- END WIDGET THUMB -->
    </div>

    <!--------------------------------  TODAY'S Payment Collection -------------------------------->
    <div class="col-md-3">
        <!-- BEGIN WIDGET THUMB -->
        <div class="widget-thumb widget-bg-color-white text-uppercase margin-bottom-20 bordered">
            <h4 class="widget-thumb-heading">TODAY'S Payment</h4>
            <div class="widget-thumb-wrap">
                <i class="widget-thumb-icon bg-blue icon-envelope"></i>
                <div class="widget-thumb-body">
                    <span class="widget-thumb-subtitle">Collection</span>
                    <a href="<?php echo base_url('Dashboard/smsHistory/').'todayPendingSms';?>">
                    <span class="widget-thumb-body-stat" id="todayPendingSmsId"  > <img src="<?php echo base_url('assets/images/loading-count.gif') ;?>"> </span>
                    </a>
                </div>
            </div>
        </div>
        <!-- END WIDGET THUMB -->
    </div>

    <!--------------------------------  TODAY'S Submitted Done -------------------------------->
    <div class="col-md-3">
        <!-- BEGIN WIDGET THUMB -->
        <div class="widget-thumb widget-bg-color-white text-uppercase margin-bottom-20 bordered">
            <h4 class="widget-thumb-heading">TODAY'S Submitted</h4>
            <div class="widget-thumb-wrap">
                <i class="widget-thumb-icon bg-purple icon-envelope"></i>
                <div class="widget-thumb-body">
                    <span class="widget-thumb-subtitle">SMS</span>
                    <a href="<?php echo base_url('Dashboard/smsHistory/').'todaySubmittedSms';?>">
                    <span class="widget-thumb-body-stat" id="todaySubmittedSmsId"  >
                        <img src="<?php echo base_url('assets/images/loading-count.gif') ;?>">
                    </span>
                    </a>
                </div>
            </div>
        </div>
        <!-- END WIDGET THUMB -->
    </div>

    <!--------------------------------  TODAY'S Failed Done -------------------------------->
    <div class="col-md-3">
        <!-- BEGIN WIDGET THUMB -->
        <div class="widget-thumb widget-bg-color-white text-uppercase margin-bottom-20 bordered">
            <h4 class="widget-thumb-heading">TODAY'S Failed</h4>
            <div class="widget-thumb-wrap">
                <i class="widget-thumb-icon bg-red icon-envelope"></i>
                <div class="widget-thumb-body">
                    <span class="widget-thumb-subtitle">SMS</span>
                    <a href="<?php echo base_url('Dashboard/smsHistory/').'todayFailedSms';?>">
                    <span class="widget-thumb-body-stat" id="todayFailedSmsId" >
                        <img src="<?php echo base_url('assets/images/loading-count.gif') ;?>">
                    </span>
                    </a>
                </div>
            </div>
        </div>
        <!-- END WIDGET THUMB -->
    </div>

<!--------------------------------  TOTAL SMS  Done-------------------------------->
    <div class="col-md-3">
        <!-- BEGIN WIDGET THUMB -->
        <div class="widget-thumb widget-bg-color-white text-uppercase margin-bottom-20 bordered">
            <h4 class="widget-thumb-heading">TOTAL SMS</h4>
            <div class="widget-thumb-wrap">
                <i class="widget-thumb-icon bg-green icon-envelope"></i>
                <div class="widget-thumb-body">
                    <span class="widget-thumb-subtitle">SMS</span>
                    <a href="<?php echo base_url('Dashboard/smsHistory/').'totalSuccessSms';?>">
                    <span class="widget-thumb-body-stat" id="totalSmsId"  >
                           <img src="<?php echo base_url('assets/images/loading-count.gif') ;?>">
                    </span>
                    </a>
                </div>
            </div>
        </div>
        <!-- END WIDGET THUMB -->
    </div>

    <!--------------------------------  TOTAL SUCCESSFUL Done -------------------------------->
    <div class="col-md-3">
        <!-- BEGIN WIDGET THUMB -->
        <div class="widget-thumb widget-bg-color-white text-uppercase margin-bottom-20 bordered">
            <h4 class="widget-thumb-heading">TOTAL SUCCESSFUL</h4>
            <div class="widget-thumb-wrap">
                <i class="widget-thumb-icon bg-green icon-envelope"></i>
                <div class="widget-thumb-body">
                    <span class="widget-thumb-subtitle">SMS</span>
                    <a href="<?php echo base_url('Dashboard/smsHistory/').'totalSuccessSms';?>">
                    <span class="widget-thumb-body-stat" id="totalSuccessSmsId"  >
                           <img src="<?php echo base_url('assets/images/loading-count.gif') ;?>">
                    </span>
                    </a>
                </div>
            </div>
        </div>
        <!-- END WIDGET THUMB -->
    </div>

    <!--------------------------------  TOTAL PENDING Done -------------------------------->
    <div class="col-md-3">
        <!-- BEGIN WIDGET THUMB -->
        <div class="widget-thumb widget-bg-color-white text-uppercase margin-bottom-20 bordered">
            <h4 class="widget-thumb-heading">TOTAL PENDING</h4>
            <div class="widget-thumb-wrap">
                <i class="widget-thumb-icon bg-blue icon-envelope"></i>
                <div class="widget-thumb-body">
                    <span class="widget-thumb-subtitle">SMS</span>
                    <a href="<?php echo base_url('Dashboard/smsHistory/').'totalPendingSms';?>">
                        <span class="widget-thumb-body-stat" id="totalPendingSmsId"  >
                            <img src="<?php echo base_url('assets/images/loading-count.gif') ;?>">
                        </span>
                    </a>
                </div>
            </div>
        </div>
        <!-- END WIDGET THUMB -->
    </div>

    <!--------------------------------  TOTAL Submitted Done -------------------------------->
    <div class="col-md-3">
        <!-- BEGIN WIDGET THUMB -->
        <div class="widget-thumb widget-bg-color-white text-uppercase margin-bottom-20 bordered">
            <h4 class="widget-thumb-heading">TOTAL Submitted</h4>
            <div class="widget-thumb-wrap">
                <i class="widget-thumb-icon bg-purple icon-envelope"></i>
                <div class="widget-thumb-body">
                    <span class="widget-thumb-subtitle">SMS</span>
                    <a href="<?php echo base_url('Dashboard/smsHistory/').'totalSubmittedSms';?>">
                    <span class="widget-thumb-body-stat" id="totalSubmittedSmsId" >
                           <img src="<?php echo base_url('assets/images/loading-count.gif') ;?>">
                    </span>
                    </a>
                </div>
            </div>
        </div>
        <!-- END WIDGET THUMB -->
    </div>

    <!--------------------------------  TOTAL Failed  Done -------------------------------->
    <div class="col-md-3">
        <!-- BEGIN WIDGET THUMB -->
        <div class="widget-thumb widget-bg-color-white text-uppercase margin-bottom-20 bordered">
            <h4 class="widget-thumb-heading">TOTAL Failed</h4>
            <div class="widget-thumb-wrap">
                <i class="widget-thumb-icon bg-red icon-envelope"></i>
                <div class="widget-thumb-body">
                    <span class="widget-thumb-subtitle">SMS</span>
                    <a href="<?php echo base_url('Dashboard/smsHistory/').'totalFailedSms';?>">
                    <span class="widget-thumb-body-stat" id="totalFailedSmsId"  >
                       <img src="<?php echo base_url('assets/images/loading-count.gif') ;?>">
                    </span>
                    </a>
                </div>
            </div>
        </div>
        <!-- END WIDGET THUMB -->
    </div>

</div>


<script>

    function setValFromAjaxToDiv(theDivName, controllerToBeCalled, urlQueryString)
    {
        ourBaseURL = '<?php echo base_url();?>';
        urlToBeCalled  = ourBaseURL + controllerToBeCalled + urlQueryString;
        
        $.ajax(urlToBeCalled , {
            success: function(data) {
                $(theDivName).html(data);
            },
            error: function() {

            }
        });    
    }
    
    $( document ).ready(function()
    {
        
        startDate = "2020-05-02";
        endDate = "2020-06-07";
        
        
        urlQueryString = startDate+"/"+endDate;
        setValFromAjaxToDiv("#OrderCountBox", "dashboard/orderCounts/", urlQueryString );
		setValFromAjaxToDiv("#PaymentCountBox", "dashboard/paymentCounts/", urlQueryString );
		
        


    });
</script>
